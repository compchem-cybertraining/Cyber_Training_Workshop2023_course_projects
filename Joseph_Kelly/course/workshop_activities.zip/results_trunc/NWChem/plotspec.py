import matplotlib.pyplot as plt

freq = []
inte = []
alt_int = []

f = open('sicl4_IR.dat', 'r')
for line in f.readlines():
    line = line.split()
    if line[0] != '#' and line[0][0]!='#':
        freq.append(float(line[0]))
        inte.append(float(line[1]))
        alt_int.append(float(line[2]))

plt.plot(freq, inte)
plt.plot(freq, alt_int)
# plt.xlim(0,70)
plt.xlabel(r'Energy ($cm^{-1}$)')
plt.ylabel('IR Absorbance')
plt.title('')
plt.show()