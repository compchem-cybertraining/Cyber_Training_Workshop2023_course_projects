import h5py

s='''S1_0-500
S1_500-1000
S1_1000-1500
S1_1500-2000
S1_2000-2500
S1_2500-3000
S1_3000-3500
S1_3500-3996
S2_0-500
S2_500-1000
S2_1000-1500
S2_1500-2000
S2_2000-2500
S2_2500-3000
S2_3000-3500
S2_3500-3996
S3_0-500
S3_500-1000
S3_1000-1500
S3_1500-2000
S3_2000-2500
S3_2500-3000
S3_3000-3500
S3_3500-3996'''

s=s.split("\n")
print(s)

for pref in s:
	fo=open("_"+pref+"_pop.dat", 'w')
	with h5py.File(F"./{pref}/mem_data.hdf", 'r') as f:
		t=f["time/data"][:]/41.0
		p=f["sh_pop_adi/data"]
		for i, v in enumerate(t):
			fo.write("%6.1f %7.4f %7.4f %7.4f %7.4f\n" %(v, p[i,0], p[i, 1], p[i, 2], p[i, 3]) )
		fo.close()
