import os
import sys
import math

from liblibra_core import *

from libra_py import units
from libra_py.packages.dftbplus import methods as DFTB_methods
import libra_py.workflows.nbra.step2_dftb as step2

EXE="dftb+"
os.system("cp dftb_tddftb.hsd dftb_in.hsd")

for i in range(0, 174320, 50):
	DFTB_methods.xyz_traj2gen_sp("Ag20-md.xyz", "x1.gen", i, "C")
	os.system(F"{EXE} > o")
	os.system(F"cp EXC.DAT  EXC_{str(i)}.dat")
